# STM32F407 + OH0117 + ILI9488 — HAL integration package

**Status: STM32 firmware reference, not verified turnkey hardware firmware.** No publicly documented OH0117 connector pinout or initialization registers are available. The OH0117 must be configured for 400x400 YUV422 UYVY, 8-bit DVP, hardware sync using the vendor SDK. If the module cannot output this format, adapt the capture and conversion code. **Do not connect pins by guessing.**

## Prerequisites
STM32CubeIDE and STM32CubeMX, STM32F4 HAL package; STM32F407VGTx or your exact part. 3.3 V IO only. OH0117 has its own documented power requirements; verify rails and IO voltage before connection.

## CubeMX project creation
1. New STM32 Project for the exact STM32F407 device, HAL firmware, default internal HSI system clock is sufficient to start. Enable SWD.
2. Enable DCMI: 8-bit, hardware sync, rising PCLK, active-high VSYNC and HSYNC **only as an initial assumption**. Confirm polarities from logic-analyzer traces or vendor timing.
3. Suggested STM32F407VG LQFP100 DCMI pins (verify AF13 and conflicts in CubeMX): PA4=HSYNC, PA6=PIXCLK, PB7=VSYNC, PC6=D0, PC7=D1, PC8=D2, PC9=D3, PC11=D4, PB6=D5, PE5=D6, PE6=D7. **Conflict:** PB6/PB7 are used for DCMI in this example; LCD control must NOT use them. See correction below.
4. Correct LCD GPIO assignments: **PD0=CS, PD1=DC, PD2=RESET**. Edit `app_camera.c` CS/DC/RST macros accordingly. (They are intentionally marked as placeholders in source.)
5. SPI1: PA5=SCK, PA7=MOSI, master, 8-bit, mode 0, software NSS, start with <=10 MHz. PA6 cannot be SPI1 MISO because it is DCMI PCLK. Disable MISO / configure transmit-only.
6. DMA2 Stream1 Channel1 for DCMI, peripheral and memory word alignment, normal mode, memory increment, peripheral-to-memory. Enable DMA2 Stream1 and DCMI NVIC interrupts. Initialize DMA before DCMI. HAL must link hdcmi.DMA_Handle.
7. I2C1 optional for SCCB, e.g. PB8=SCL PB9=SDA; actual OH0117 slave address/register map requires vendor SDK.
8. GPIO output PD0/PD1/PD2, initial CS high and RESET high. Change macros in source to PD0, PD1, PD2.
9. Generate code. Copy `Core/Inc/app_camera.h` and `Core/Src/app_camera.c` into generated project; include source in build; paste `integration_snippet.c.txt` into USER CODE sections.
10. Check the DCMI HAL crop argument order in your installed HAL version. This sample calls `(X0,Y0,XSize,YSize)` = `(240,120,319,159)` where horizontal units are byte clocks. Inspect the installed HAL definition before flashing.
11. Build with Project > Build Project; flash via ST-LINK. First test LCD with a fixed-color pattern, then validate DVP waveforms and capture bytes. Only then enable camera streaming.

## Limitations
- 160x160 YUV422 center crop from 400x400 source, scaled 2x to 320x320 and centered on 480x320 TFT.
- 51,200-byte frame in DMA-visible SRAM; LCD is written after capture, avoiding ISR blocking.
- ILI9488 3-byte RGB666 SPI writes. Some boards require a longer vendor-specific init sequence and different MADCTL orientation.
- Sensor initialization and exact DVP pin assignments are **not supplied**, because vendor SDK/connector documents are required.
- DMA and DCMI sync polarities, byte order, cropping timing must be verified on hardware.
- Camera frame timeout may require adjustment to output frame rate.
- SPI speed and TFT wiring determine actual FPS.

References: https://www.ovt.com/products/oh0117/ ; https://www.st.com/resource/en/reference_manual/rm0090-stm32f407-advanced-armbased-32bit-mcus-stmicroelectronics.pdf ; https://www.displayfuture.com/Display/datasheet/controller/ILI9488.pdf
