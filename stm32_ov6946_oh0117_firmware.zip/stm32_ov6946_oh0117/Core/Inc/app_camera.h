#pragma once
#include "stm32f4xx_hal.h"
void App_Init(void);
void App_Loop(void);
void App_DcmiFrame(DCMI_HandleTypeDef *h);
void App_DcmiError(DCMI_HandleTypeDef *h);
