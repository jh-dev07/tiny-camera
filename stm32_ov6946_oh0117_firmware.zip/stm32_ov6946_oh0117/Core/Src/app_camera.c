#include "app_camera.h"
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
extern DCMI_HandleTypeDef hdcmi;
extern SPI_HandleTypeDef hspi1;
/* 160x160 YUV422 snapshot = 51200 bytes, DMA-visible SRAM */
#define W 160u
#define H 160u
#define WORDS (W*H*2u/4u)
static uint32_t capture[WORDS] __attribute__((aligned(4)));
static uint8_t rgb[W*2u*3u];
static volatile uint8_t finished, failed;
static uint32_t frames, errors;
/* Example pins, configurable; not an OH0117 connector pinout */
#define CS GPIOD,GPIO_PIN_0
#define DC GPIOD,GPIO_PIN_1
#define RST GPIOD,GPIO_PIN_2
static void pin(GPIO_TypeDef *p,uint16_t n,GPIO_PinState v){HAL_GPIO_WritePin(p,n,v);}
static void cmd(uint8_t c){pin(DC,GPIO_PIN_RESET);pin(CS,GPIO_PIN_RESET);HAL_SPI_Transmit(&hspi1,&c,1,100);pin(CS,GPIO_PIN_SET);}
static void data(const uint8_t *d,uint16_t n){pin(DC,GPIO_PIN_SET);pin(CS,GPIO_PIN_RESET);HAL_SPI_Transmit(&hspi1,(uint8_t*)d,n,1000);pin(CS,GPIO_PIN_SET);}
static void window(uint16_t x0,uint16_t y0,uint16_t x1,uint16_t y1){
 uint8_t a[4];cmd(0x2A);a[0]=x0>>8;a[1]=x0;a[2]=x1>>8;a[3]=x1;data(a,4);
 cmd(0x2B);a[0]=y0>>8;a[1]=y0;a[2]=y1>>8;a[3]=y1;data(a,4);cmd(0x2C);
}
static void lcd_init(void){
 pin(CS,GPIO_PIN_SET);pin(RST,GPIO_PIN_RESET);HAL_Delay(20);pin(RST,GPIO_PIN_SET);HAL_Delay(120);
 cmd(0x01);HAL_Delay(150);cmd(0x11);HAL_Delay(120);
 uint8_t pf=0x66;cmd(0x3A);data(&pf,1); /* SPI RGB666 */
 uint8_t mad=0x28;cmd(0x36);data(&mad,1); /* landscape; panel-dependent */
 cmd(0x29);HAL_Delay(20);
}
static uint8_t clip(int x){return x<0?0:(x>255?255:(uint8_t)x);}
static void yuv_to_rgb(uint8_t y,uint8_t u,uint8_t v,uint8_t *dst){
 int c=(int)y-16,d=(int)u-128,e=(int)v-128;if(c<0)c=0;
 uint8_t r=clip((298*c+409*e+128)>>8),g=clip((298*c-100*d-208*e+128)>>8),b=clip((298*c+516*d+128)>>8);
 dst[0]=r&0xFC;dst[1]=g&0xFC;dst[2]=b&0xFC;
}
/* Assumes OH0117 emits UYVY: U Y0 V Y1; verify with SDK. */
static void draw(void){
 const uint8_t *raw=(const uint8_t*)capture;
 window(80,0,399,319);pin(DC,GPIO_PIN_SET);pin(CS,GPIO_PIN_RESET);
 for(uint32_t y=0;y<H;y++){
  for(uint32_t x=0;x<W;x+=2){
   const uint8_t *q=raw+(y*W+x)*2u;
   uint8_t a[3],b[3];yuv_to_rgb(q[1],q[0],q[2],a);yuv_to_rgb(q[3],q[0],q[2],b);
   for(unsigned k=0;k<2;k++){memcpy(rgb+(2*x+k*2)*3,a,3);memcpy(rgb+(2*x+k*2+2)*3,b,3);}
  }
  /* double each camera line: 320 display pixels, 960 bytes */
  HAL_SPI_Transmit(&hspi1,rgb,W*2*3,1000);
  HAL_SPI_Transmit(&hspi1,rgb,W*2*3,1000);
 }
 pin(CS,GPIO_PIN_SET);
}
/* Crop dimensions and offsets are in DCMI pixel-clock units / bytes;
   this sample assumes 8-bit YUV422, 2 PCLK per pixel, and 400x400 source.
   CAPCNT = 160*2 - 1; VLINE = 160 - 1; offsets 120*2,120.
   Verify HSYNC timing and crop start with actual OH0117 DVP signals. */
static HAL_StatusTypeDef start(void){
 finished=0;failed=0;
 if(HAL_DCMI_ConfigCrop(&hdcmi,240,120,319,159)!=HAL_OK)return HAL_ERROR;
 if(HAL_DCMI_EnableCROP(&hdcmi)!=HAL_OK)return HAL_ERROR;
 return HAL_DCMI_Start_DMA(&hdcmi,DCMI_MODE_SNAPSHOT,(uint32_t)capture,WORDS);
}
void App_DcmiFrame(DCMI_HandleTypeDef *h){if(h==&hdcmi)finished=1;}
void App_DcmiError(DCMI_HandleTypeDef *h){if(h==&hdcmi)failed=1;}
void App_Init(void){lcd_init(); /* OH0117 must be configured externally via vendor SDK */}
void App_Loop(void){
 if(start()!=HAL_OK){errors++;HAL_Delay(200);return;}
 uint32_t t=HAL_GetTick();
 while(!finished&&!failed&&(HAL_GetTick()-t<500)){}
 HAL_DCMI_Stop(&hdcmi);
 if(failed||!finished){errors++;HAL_Delay(50);return;}
 draw();frames++;
}
